"""Bundled conversion data resources."""
